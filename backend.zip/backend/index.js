require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);


app.use(
  cors({
    credentials: true,
    origin: ["http://localhost:4200"],
    methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"], 
    })
);

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log("Connected to MongoDB"))
  .catch((err) => console.log("MongoDB connection error:", err));


// Middleware for JSON ??? 
app.use(express.json());

// Basic route to test the server
app.get('/', (req, res) => {
  res.send("Backend server is running!");
});

// Import and use user routes
const userRoutes = require('./routes/userRoutes');
const postRoutes = require('./routes/postRoutes');
const PrivateMessageRoutes = require('./routes/PrivateMessageRoutes');
const notificationRoutes = require('./routes/notificationRoutes'); 
const friendshipRoutes = require('./routes/friendshipRoutes'); 
const ChatSessionRoutes = require('./routes/ChatSessionRoutes');
app.use('/api/users', userRoutes); // Les routes utilisateurs sont maintenant accessibles sous "/api/users"
app.use('/api/posts', postRoutes);
app.use('/api/PM', PrivateMessageRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/friends', friendshipRoutes); 
app.use('/api/chat', ChatSessionRoutes); 

// Socket.IO configuration for real-time connection
io.on('connection', (socket) => {
  console.log("New WebSocket connection");
  socket.on('message', (data) => {
    console.log("Received message:", data);
    io.emit('message', data);
  });
});

// Start the server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
