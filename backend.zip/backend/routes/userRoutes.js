const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');

// Route pour créer un utilisateur
router.post('/create', userController.createUser); // Tester l'api sur postman

// Route pour supprimer un utilisateur
router.delete('/users/:userId', userController.deleteUser); // Tester l'api sur postman

// Route pour mettre à jour les informations personnelles de l'utilisateur : 
// Modifier le pseudonyme de l'utilisateur 
router.put('/:userId/pseudo', userController.updatePseudonym); 

// Modifier l'Email de l'utilisateur  
router.put('/:userId/email', userController.updateEmail); 

// Route pour mettre à jour le mot de passe de l’utilisateur
router.put('/:userId/password', userController.updatePassword); // Tester l'api sur postman

// Modifier le prénom de l'utilisateur 
router.put('/:userId/firstname', userController.updateFirstName);

// Modifier le nom d'un utilisateur 
router.put('/:userId/lastname', userController.updateLastName);

// Modifier l'âge d'un utilisateur 
router.put('/:userId/age', userController.updateAge); 

// Modifier le genre d'un utilisateur 
router.put('/:userId/genre', userController.updateGender);

// Modifier la bio d'un utilisateur 
router.put('/:userId/bio', userController.updateBio); 

// Modifier les préférences d'un utilisateur (groupe ou communauté) 
router.put('/:userId/preferences', userController.updatePreferences);

// Modifier la photo d'un utilisateur 
router.put('/:userId/photo', userController.updatePhoto);

// Ajouter des connexions (amis) d'un utilisateur 
router.post('/:userId/addfriend', userController.addFriend);

// Supprimer des connexions (amis) d'un utilisateur 
router.delete('/:userId/removefriend', userController.removeFriend);

// Pour voir le profil d'un utilisateur 
router.get('/:userId/seeprofile', userController.seeProfile);

router.post('/login', userController.loginUser);

// Pour récupérer les données de l'utilisateur et les afficher sur le front
router.get('/', userController.getUser); 


module.exports = router;
