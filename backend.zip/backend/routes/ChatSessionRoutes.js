const express = require('express');
const chatSessionController = require('../controllers/chatSessionController');
const router = express.Router(); 

// Route pour publier un message dans une discussion instantanée
router.post('/send/', chatSessionController.sendChatMessage);

// Route pour supprimer un message dans une discussion instantanée. 
router.delete('/delete/:messageId', chatSessionController.deleteChatMessage); 

// Route pour inviter un ami à participer à une discussion instantanée. 
router.post('/invite/:friendId', chatSessionController.inviteFriendToChat); 

// Route pour inviter un membre à participer à une discussion instantanée. 
router.post('/invitation/:userId', chatSessionController.inviteMemberToChat);

module.exports = router;