const express = require('express');
const notificationController = require('../controllers/notificationController');
const router = express.Router(); 

// Route pour créer une notification
router.post('/create', notificationController.createNotification); 

// Route pour récupérérer les notifications d'un utilisateur 
router.get('/:userId', notificationController.getUserNotification);

// Route pour marquer une notification comme lu 
router.put('/:notificationId/read', notificationController.markAsReadNotification);

module.exports = router;