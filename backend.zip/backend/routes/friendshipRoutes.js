const express = require('express');
const friendshipController = require('../controllers/friendshipController');
const router = express.Router(); 

// Route pour rechercher des amis par pseudonyme, prénom ou nom
router.get('/searchfriends', friendshipController.searchFriends);

// Route pour voir la liste d'amis de l'utilisateur (ou du visiteur ?)
router.get('/seefriendslist', friendshipController.seeFriendsList); 

// Route pour recommander un membre
router.post("/recommend/:userId", friendshipController.recommendMember);

module.exports = router;