const express = require('express');
const postController = require('../controllers/postController');
const router = express.Router(); 

router.post('/create', postController.createPost); // Route pour créer une publication
router.post('/delete/:PostId', postController.deletePost); // Route pour supprimer une publication
router.post('/comment/:postId', postController.addComment); // Route pour ajouter un commentaire

// Route pour supprimer un commentaire 
router.delete('/delete/comment', postController.deleteComment);
 
router.get('/allposts', postController.seeAllPosts); // Route pour voir toutes les publications 
router.get('/seespecificpost', postController.seeSpecificPost); // Route pour voir certaines publications 

module.exports = router;
