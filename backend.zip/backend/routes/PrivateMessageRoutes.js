const express = require('express');
const router = express.Router(); 
const PrivateMessageController = require('../controllers/PrivateMessageController');

// Route pour envoyer un message privé
router.post('/send', PrivateMessageController.createPM); 

// Route pour supprimer un message privé
router.delete('/delete/:PrivateMessageId', PrivateMessageController.deletePM); 

module.exports = router;