const mongoose = require('mongoose');

// Gère les relation entre utilisateurs en traçant les demandes, les amitiés confirmés et les recommandations
const FriendshipSchema = new mongoose.Schema({
    requester: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    recipient: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    status: { type: String, enum: ['pending', 'confirmed', 'recommended', 'refused'], default: 'pending' }
});

// Gère les recommandations entre utilisateurs / membres 
const recommendationSchema = new mongoose.Schema({
    recommender: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true }, // Celui qui recommande
    recipient: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true }, // Celui qui reçoit la recommandation
    recommended: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true }, // Le membre recommandé
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("Recommendation", recommendationSchema);

module.exports = mongoose.model('Friendship', FriendshipSchema);
