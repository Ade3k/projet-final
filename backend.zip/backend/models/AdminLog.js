const mongoose = require('mongoose');

// Pour garder une trace des actions effectuées par les administrateurs pour la gestion et la modération
const AdminLogSchema = new mongoose.Schema({
    admin: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    action: { type: String, required: true },
    details: String,
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('AdminLog', AdminLogSchema);

// Voir tous les profils
// modifier tous les profils
// supprimer tous les profils
// Affichage des statistiques en temps réel : connexions, messages reçus et envoyés.
// supprimer un message sur le profil de n'importe quel membre
// recommander à n'importe quel membre d’ajouter un ami à sa liste d’amis