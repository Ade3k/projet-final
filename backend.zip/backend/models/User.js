const mongoose = require('mongoose');

// Gère la création d'un utilisateur 
const UserSchema = new mongoose.Schema({
    pseudonym: { type: String, required: true, unique: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true }, // On doit ajouter le hash pour sécuriser le mot de passe
    firstName: String,
    lastName: String,
    age: Number,
    gender: String,
    photo: String, 
    bio: String, 
    preferences: [String], 
    friends: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }], // Liste des amis
    friendRequests: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }], // Demandes d’amis
    recommendations: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }], // Recommandations d’amis
    isAdmin: { type: Boolean, default: false } // Statut admin
});

module.exports = mongoose.model('User', UserSchema);
