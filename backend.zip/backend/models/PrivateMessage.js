const mongoose = require('mongoose');

// Gère la messagerie privée entre les utilisateurs permettant les discussion entre 2 personnes ou plus
const PrivateMessageSchema = new mongoose.Schema({
    participants: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }],
    messages: [{
        sender: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
        content: { type: String, required: true },
        createdAt: { type: Date, default: Date.now }
    }]
});

module.exports = mongoose.model('PrivateMessage', PrivateMessageSchema);
