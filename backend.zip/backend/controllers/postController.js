const Post = require('../models/Post');

// Créer une nouvelle publication
exports.createPost = async (req, res) => {
    try {
        const { Author, content } = req.body; 
        const newPost = new Post ({
            author : Author, 
            content
        });

        const savedPost = await newPost.save();
        res.status(201).json({ message: "Post créé avec succès", savedPost });
        
}
    catch (error) {
        res.status(500).json({ message: "Erreur lors de la création du post"});
    }
};

// Supprimer une publication 
exports.deletePost = async (req, res) => {
    try {
        const { PostId } = req.params;

        const deletedPost = await Post.findByIdAndDelete(PostId);

        if (!deletedPost) {
            return res.status(404).json({ message: "Post introuvable" });
        }
        res.status(201).json({ message: "Post supprimé avec succès" }); 
    }  
    catch (error) {
        res.status(500).json({ message: "Erreur lors de la suppression du post"});
    }
    };

// Pour ajouter un commentaire à une publication
exports.addComment = async (req, res) => {
    try{
        const { PostId, Author, content } = req.body;

        const post = await Post.findById(PostId);

        if (!post) {
            return res.status(404).json({ message: "Publication non trouvée" });
        }
        const comment = { author:Author, content };
        post.comments.push( comment );
        await post.save(); 

        res.status(201).json({ message: "Ajout du commentaire avec succès", post });
    }
    catch (error) {
        res.status(500).json ({ message: "Erreur lors de l'ajout du commentaire" });
    }
}

// Pour supprimer un commentaire à une publication 
exports.deleteComment = async (req, res) => {
    try {
        const { content } = req.body; // Exemple de critère : contenu du commentaire

        if (!content) {
            return res.status(400).json({ message: "Le contenu du commentaire est requis pour cette opération" });
        }

        const deletedComment = await Comment.findOneAndDelete({ content });

        if (!deletedComment) {
            return res.status(404).json({ message: "Aucun commentaire correspondant trouvé" });
        }

        res.status(200).json({ message: "Le commentaire a été supprimé avec succès", deletedComment });
    } catch (error) {
        res.status(500).json({ message: "Erreur lors de la suppression du commentaire", error });
    }
}; // Fonctionne pas 


// Pour afficher le post 
exports.seeAllPosts = async (req, res) => {
    try {
        const posts = await Post.find().sort({ createdAt: -1 });
        
        if (!posts.length) {
            return res.status(404).json({ message: "Aucune publication trouvée" });
        }
        res.status(200).json(posts);
    } catch (error) {
        res.status(500).json({ message: "Erreur lors de l'affichage du post", error });
    };
}; 

// Pour récupérer une publication par son id
exports.seeSpecificPost = async (req, res) => {
    try {
        const { postId } = req.body;
        const specificPost = await Post.findById(postId)

        if (!specificPost) {
            return res.status(200).json({ message: "Publication introuvable" });
        }
        res.status(200).json(specificPost); 
    } catch (error) {
        res.status(500).json({ message: "Erreur lors de l'affichage du post", error });
    };
};