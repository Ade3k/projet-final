const { json } = require('body-parser');
const Notification = require('../models/Notification Model')

// Gérer des notifications 
exports.createNotification = async(req, res) => {
    try{
        const { user, message } = req.body;

        const newNotification = new Notification ({
            user,
            message
        });
    
    const savedNotification = await newNotification.save();
    res.status(201).json({ savedNotification })
    } catch (error) {res.status(500).json({ message: "Erreur lors de l'envoi de la notification" })}
}

// Alerter l'utilisateur
exports.getUserNotification = async(req, res) => {
    try{
        const { userId } = req.params;

        const notifications = await Notification.find({ user:userId });
        res.status(200).json( notifications ); 
    } catch (error) {res.status(500).json({ message: "Erreur lors de la récupération des notifications" })}
}

// Notification lu 
exports.markAsReadNotification = async(req, res) => {
    try{
        const { notificationId } = req.params; 

        const notification = await Notification.findByIdAndUpdate(notificationId, {isRead: true}); 
        if (!notification) {
            return res.status(404).json({ message: "notification non trouvée"})
        }
        res.status(200).json({ message: "notification trouvée" })
    } catch (error) {res.status(500).json({ messaage: "Erreur"})}
}