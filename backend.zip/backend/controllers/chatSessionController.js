const ChatSession = require('../models/ChatSession Model');

// Publier un message dans une discussion instantanée (c'est-à-dire, envoyer / créer un message instantané). 
exports.sendChatMessage = async (req, res) => {
    try {
        const { participants, messages } = req.body; 

        const newChatMessage = new Chat({ // Création d'un nouveau message de discussion
            participants, // Liste des participants à la discussion
            messages: [
                {
                    sender: participants[0], // Expéditeur par défaut : premier participant
                    content: messages,
                    timestamp: new Date()
                }
            ]
        });

        const savedChatMessage = await newChatMessage.save(); // Sauvegarder le message dans la base de données
        res.status(200).json({ message: "Message instantané créé avec succès", savedChatMessage });
        
}
    catch (error) {
        res.status(500).json({ message: "Erreur lors de la création du message instanté", error});
    }
}; // Code à corriger

// Supprimer un message dans une discussion instantanée. 
exports.deleteChatMessage = async (req, res) => {
    try {
        const { ChatMessageId } = req.params; // ID du message à supprimer 

        const deletetedChatMessage = await ChatSession.findByIdAndDelete(ChatMessageId);

        if (!deletetedChatMessage) {
            return res.status(404).json({ message: "Message instantané introuvable" });
        }
        res.status(200).json({ message: "Message instantané supprimé avec succès" }); 
    } catch (error) {
        res.status(500).json({ message: "Erreur lors de la suppression du message instantané", error }); 
    };
}; // Code à corriger 

// Inviter un ami à participer à une discussion instantanée. 
exports.inviteFriendToChat = async (req, res) => {
    try {
        const { friendId } = req.params; 
        const { participants } = req.body; 

        const inviteToChat = await ChatSession.find(friendId);
        if (!inviteToChat) {
            res.status(404).json({ message: "Invitation introoouvable" });
        }
        res.status(200).json({ message: "Invitation envoyé avec succès" }); 
    } catch (error) {
        res.status(500).json({ message: "Erreur lors de l'envoi de l'invitation à session chat", error }); 
    };
}; // Code à corriger

// Inviter un membre à participer à une discussion instantanée. 
exports.inviteMemberToChat = async (req, res) => {
    try {
        const { userId } = req.params; // Identifiant du membre à inviter
        const { chatId } = req.body; // Identifiant de la session de chat

        // Vérifier si la session de chat existe
        const ChatSession = await ChatSession.findbyId(chatId);
        if (!ChatSession) {
            res.status(404).json({ message: "Session de chat introuvable" });
        }

        // Vérifier si le membre est déjà dans la session
        if (userId)

        res.status(200).json({ message: "Invitation envoyé avec succès" }); 
    } catch (error) {
        res.status(500).json({ message: "Erreur lors de l'envoi de l'invitation à session chat", error }); 
    };
}; // Code à corriger

// Rejoindre une discussion instantanée. 

// Un membre peut: 
//          - ouvrir un sujet de discussion avec plusieurs amis 
//          - ouvrir un sujet de discussion avec n'importe quel membre 
//          - supprimer un sujet de discussion qu’il a ouvert 
//          - supprimer un sujet de discussion ouvert par n'importe quel autre membre peut publier un message sur un sujet 
//          de discussion auquel il participe
//          - supprimer un message qu’il a publié sur un sujet de discussion auquel il participe
//          - publier un message sur n’importe quel sujet de discussion
//          - supprimer un message sur n’importe quel sujet de discussion

// Un membre peut : 
//          - Accepter de rejoindre une discussion instantanée
//          - Publier un message dans une discussion instantanée
//          - Inviter un ami à participer à une discussion instantanée
//          - Inviter un membre à participer à une discussion instantanée