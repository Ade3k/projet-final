const PrivateMessage = require('../models/PrivateMessage');

// Créer un message privé
exports.createPM = async (req, res) => {
    try {
        const { senderID, recipientID, messages } = req.body;

        const newPrivateMessage = new PrivateMessage({
            participants:[senderID, recipientID],
            messages:
                [{
                    sender: senderID,
                    content: messages
                }]
        });

        const savedPM = await newPrivateMessage.save();
        res.status(201).json({ message: "Message crée avec succès", user: savedPM });
    } catch (error) {
        res.status(500).json({ message: "Erreur lors de la création du message", error });
    }
};

// Supprimer un message privé
exports.deletePM = async (req, res) => {
    try {
        const { PMId} = req.params;

        const deletePM = await PrivateMessage.findByIdAndDelete(PMId)

        if (!deletePM) {
            return res.status(404).json({ message: "Le message n'a pas été suprimé"});
        }

        res.status(200).json({ message: "Le message a été supprimé avec succès"});
    } catch (error) {
        res.status(500).json({ message: "Erreur lors la suppression du message" });
    }
};
