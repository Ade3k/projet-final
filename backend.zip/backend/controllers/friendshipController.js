const { Model } = require("mongoose");
const Friendship = require("../models/Friendship");

// Pour saisir dans le champ de filtrage. ???

// Pour rechercher des membres par nom et/ou prénom et/ou pseudonyme. 
exports.searchFriends = async (req, res) => { 
    try {
        const { pseudonym,firstName, lastName } = req.query // Récupérer la catégorie depuis la query string 
        
        if (!pseudonym && !firstName && !lastName) {
            return res.status(400).json({ message: "Un pseudonyme, un nom ou un prénom sont requis pour effectuer la recherche" })
        }

        const selection = await User.findOne({
            $or: [
                { pseudonym },
                { firstName },
                { lastName }
            ]
        });

        if (!selection) { // Si aucun utilisateur est trouvé dans les critères 
            return res.status(404).json({ message: 'Ce membre est introuvable avec les informations donnée' });
        }
        res.status(200).json({ message: "Utilisateur trouvé avec succès." });    
    } catch (error) {
        res.status(500).json({ message: 'Erreur lors de la recherche', error });
    };
}; // Code à corriger 

// Pour filtrer la liste des amis pour afficher uniquement ceux qui correspondent à la chaîne de caractères 

// Pour voir la liste d'amis
exports.seeFriendsList = async (req, res) => {
    try {
        const { userId } = req.params;
        const { friendId } = req.body;

        // Filtrer les amitiés acceptées
        const friendships = await Friendship.find({ status: "confirmed" });

        const user = await User.findById(userId).sort();
        const friend = await User.findById(friendId);

        if (!user) {
            return res.status(404).json({ message: "Utilisateurs introuvables" });
        }

        if (!friend) {
            return res.status(404).json({ message: "Ami introuvable" });
        }

        if (!friendships) {
            return res.status(404).json({ message: "Amis introuvables" });
        }
        return res.status(200).json({ message: "Liste d'amis récupéré avec succès" });
    } catch (error) {
        return res.status(500).json({ message: "Erreur lors de l'affichage du la liste", error });
    }
}; // Code à corriger 

// Pour ajouter un utilisateur à sa liste d’amis ??? 

// Pour recommander un membre à une connaissance.
exports.recommendMember = async (req, res) => {
    try {
        const { memberId } = req.params;
        const { recipient } = req.body;

        const connexion = await memberId.findOne(recipient);

        if (!connexion) {
            return res.status(404).json({ message: "Aucune connexion n'éxiste" });
        }
        res.status(200).json({ message: "Connexion établie" });

        const recommendedMember = await Friendship.findById(
            memberId,
            { recipient }
        );

        if (!recommendedMember) {
            return res.status(404).json({ message: "Recommandation introuvable" });
        }
        res.status(200).json({ message: "Recommandation de connexion établie avec succès" }); 
    } catch (error) {
        res.status(500).json({ message: "Erreur lors de la recommandation de connexion", error });
    };
}; // Code à corriger 

// Pour voir le profil d'un ami ??? 
