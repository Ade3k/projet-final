const User = require('../models/User');
const { use } = require('../routes/userRoutes');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

// Créer un nouvel utilisateur
exports.createUser = async (req, res) => {
    try {
        const { pseudonym, email, password, firstName, lastName, age, gender, bio, preferences } = req.body;

        const cryptedPassword = await bcrypt.hash(password, 10);

        const newUser = new User({
            pseudonym,
            email,
            password: cryptedPassword, // Crée un système de sécurité
            firstName,
            lastName,
            age,
            gender,
            bio,
            preferences
        });

        console.log(newUser)
        const savedUser = await newUser.save();
        res.status(201).json({ message: "Utilisateur créé avec succès", user: savedUser });
    } catch (error) {
        console.log(error.body)
        res.status(500).json({ message: "Erreur lors de la création de l'utilisateur", error });
    }
};

// Supprimer un utilisateur
exports.deleteUser = async (req, res) => {
    try {
        const { userId } = req.params;

        const deletedUser = await User.findByIdAndDelete(userId);

        if (!deletedUser) {
            return res.status(404).json({ message: "Utilisateur non trouvé" });
        }

        res.status(200).json({ message: "Utilisateur supprimé avec succès" });
    } catch (error) {
        res.status(500).json({ message: "Erreur lors de la suppression de l'utilisateur", error });
    }
};

// Pour mettre à jour les informations personnelles :(3 ou plus: mots de passe, Informations personnelles, photo et contenu visuel, 
// bio, groupes ou communautés, ajout ou suppression de connexions : amis)

// Modifier le pseudonyme d'un utilisateur 
exports.updatePseudonym = async (req, res) => {
    try {
        const { userId } = req.params;
        const { newPseudonym } = req.body;

        // Vérifier si le nouveau pseudonyme existe déjà dans la base de données
        const existingUser = await User.findOne({ pseudonym: newPseudonym });
        if (existingUser && existingUser._id.toString() !== userId) {
            return res.status(400).json({ message: "Ce pseudonyme est déjà utilisé par un autre utilisateur" });
        }
        // Mettre à jour le pseudonyme
        const updatedUser = await User.findByIdAndUpdate(
            userId,
            { pseudonym: newPseudonym },
            { new: true }
        );

        if (!updatedUser) {
            return res.status(404).json({ message: "Utilisateur non trouvé" });
        }

        res.status(200).json({ message: "Pseudonym mis à jour avec succès", user: updatedUser });
    } catch (error) {
        res.status(500).json({ message: "Erreur lors de la mise à jour du pseudonym", error: error.message });
    }
};

// Modifier l'email d'un utilisateur 
exports.updateEmail = async (req, res) => {
    try {
        const { userId } = req.params;
        const { newEmail } = req.body;

        // Pour vérifier si le nouvel email existe déjà dans la base de données et éviter les doublons
        const existingUser = await User.findOne({ email: newEmail });
        if (existingUser && existingUser._id.toString() !== userId) {
            return res.status(400).json({ message: "Cet email est déjà utilisé par un autre utilisateur" });
        }

        const updatedUser = await User.findByIdAndUpdate(
            userId,
            { email: newEmail }, 
            { new: true }
        );

        if (!updatedUser) {
            return res.status(404).json({ message: "Utilisateur non trouvé" });
        }

        res.status(200).json({ message: "Email mis à jour avec succès" });
    } catch (error) {
        res.status(500).json({ message: "Erreur lors de la mise à jour du email", error });
    }
};

// Modifier le mot de passe d'un utilisateur
exports.updatePassword = async (req, res) => {
    try {
        const { userId } = req.params;
        const { newPassword } = req.body;

        const updatedUser = await User.findByIdAndUpdate(
            userId,
            { password: newPassword }, 
            { new: true }
        );

        if (!updatedUser) {
            return res.status(404).json({ message: "Utilisateur non trouvé" });
        }

        res.status(200).json({ message: "Mot de passe mis à jour avec succès" });
    } catch (error) {
        res.status(500).json({ message: "Erreur lors de la mise à jour du mot de passe", error });
    }
};

// Modifier le prénom d'un utilisateur 
exports.updateFirstName = async (req, res) => {
    try {
        const { userId } = req.params; 
        const { newFirstName } = req.body;

        const updatedUser = await User.findByIdAndUpdate(
            userId,
            { firstName: newFirstName },
            { new: true },
        );

        if (!updatedUser) {
            return res.status(404).json({ message: "Utilisateur non trouvé" });
        }

        res.status(200).json({ message: "Le prénom à été modifié avec succès" });
    } catch (error) {
        res.status(500).json({ message: "Erreur lors de la modification du prénom", error });
    }
}; 

// Modifier le nom d'un utilisateur 
exports.updateLastName = async (req, res) => {
    try {
        const { userId } = req.params;
        const { newLastName } = req.body;

        const updatedUser = await User.findByIdAndUpdate(
            userId,
            { lastName: newLastName }, 
            { new: true },
        );

        if (!updatedUser) {
            return res.status(404).json({ message: "Utilisateur non trouvé" });
        }

        res.status(200).json({ message: "Le nom à été modifié avec succès" });
    } catch (error) {
        res.status(500).json({ message: "Erreur lors de la modification du nom", error });
    }
};

// Modifier l'âge d'un utilisateur 
exports.updateAge = async (req, res) => {
    try {
        const { userId } = req.params;
        const { newAge } = req.body;

        const updatedUser = await User.findByIdAndUpdate(
            userId,
            { age: newAge },
            { new: true }, 
        );
        if (!updatedUser) {
            return res.status(404).json({ message: "Utilisateur introuvable" }); 
        }
        res.status(200).json({ message: "L'âge à été mis à jour avec succès" }); 
    } catch (error) {
        res.status(500).json({ message: "Erreur lors de la mis à jour de l'âge", error });
    }
};

// Modifier le genre d'un utilisateur 
exports.updateGender = async (req, res) => {
    try {
        const { userId } = req.params;
        const { newGender } = req.body; 
        
        const updatedUser = await User.findByIdAndUpdate(
            userId,
            { gender: newGender},
            { new: true },
        );
        if (!updatedUser) {
            return res.status(404).json({ message: "Utilisateur introuvable" });
        }
        res.status(200).json({ message: "Le genre à été modifié avec succès" });
    } catch (error) {
        res.status(500).json({ message: "Erreur lors de la modification du genre", error });
    }
};

// Modifier la bio d'un utilisateur 
exports.updateBio = async (req, res) => {
    try {
        const { userId } = req.params;
        const { newBio } = req.body; 

        const updatedUser = await User.findByIdAndUpdate(
            userId,
            { bio: newBio },
            { new: true }, 
        );
        if (!updatedUser) {
            return res.status(404).json({ message: "Utilisateur introuvable" });
        }
        res.status(200).json({ message: "la bio a été modifié avec succès" });
    } catch (error) {
        res.status(500).json({ message: "Erreur lors de la mise à jour de la bio", error });
    }
};

// Modifier les préférences d'un utilisateur (groupe ou communauté) 
exports.updatePreferences = async (req, res) => {
    try {
        const { userId } = req.params; 
        const { newPreferences } = req.body;

        const user = await User.findById(
            userId
        ); 
        if(!user) {
            return res.status(404).json({ message: "Utilisateur introuvable" });
        }
        if(!newPreferences) {
            return res.status(400).json({ message: "Des préférences doivent être ajoutés" });
        }

        user.preferences = newPreferences;
        await user.save(); 
        res.status(200).json({ message: "Les préférences ont été mis à jour avec succès" });
    } catch (error) {
        res.status(500).json({message: "Erreur lors de la mis à jour des préférences", error });
    }
};

// Modifier la photo d'un utilisateur 
exports.updatePhoto = async (req, res) => {
    try {
        const { userId } = req.params;
        const { newPhotoUrl } = req.body;

        const updatedUser = await User.findByIdAndUpdate(
            userId,
            { photo: newPhotoUrl },
            { new: true }
        );
        if (!updatedUser) {
            return res.status(404).json({ message: "Utilisateur introuvable" });
        } 
        res.status(200).json({ message: "La photo de profile à été modifiée avec succès" });
    } catch (error) {
        res.status(500).json({ message: "Erreur lors de la mis à jour de la photo de profile", error });
    }
};

// Ajouter des connexions (amis) d'un utilisateur 
exports.addFriend = async (req, res) => {
    try {
        const { userId } = req.params; // url
        const { friendId } = req.body; // postman

        const user = await User.findById( userId );
        const friend = await User.findById( friendId );

        if (!user || !friend) {
            return res.status(404).json({ message: "Utilisateur introuvable" });
        } 
        if (!user.friends.includes(friendId)) {
            user.friends.push(friendId);
            await user.save();

            friend.friends.push(userId);
            await friend.save();
        }

        res.status(200).json({ message: "Ami ajouté avec succès" });
    } catch (error) {
        res.status(500).json({ message: "Erreur lors de l'ajout d'un ami", error });
    }
};

// Supprimer des connexions (amis) d'un utilisateur 
exports.removeFriend = async (req, res) => {
    try {
        const userId = req.params.userId;
        const { friendId } = req.body;

        if (!userId || !friend) { // Vérifier si l'un des deux utilisateurs n'existe pas
            return res.status(404).json({ message: "Utilisateur et amis sont requis" });
        }

        const user = await User.findById(userId);
        const friend = await User.findById(friendId);
    
        // Supprimer le friendId de la liste des amis de l'utilisateur userId
        user.friends = user.friends.filter(id => id.toString() !== friendId);
        await user.save();

        friend.friends = friend.friends.filter(id => id.toString()!== userId);
        await friend.save();

        if (!user || !friend) { // Vérifier si l'un des deux utilisateurs n'existe pas
            return res.status(404).json({ message: "Utilisateur introuvable" });
        }
        res.status(200).json({ message: "Ami supprimé avec succès", user, friend });
    } catch (error) {
        res.status(500).json({ message: "Erreur lors de la suppression d'un ami", error });
    }
}; // À revoir car ne fonctionne pas

// Pour voir le profil d'un utilisateur 
exports.seeProfile = async (req, res) => {
    try {
        const { userId } = req.params;
        
        const user = await User.findById(userId).select('-password');

        if (!user) {
            return res.status(404).json({ message: "Utilisateur introuvable" });
        }
        return res.status(200).json({ user });
    } catch (error) {
        return res.status(500).json({ message: "Erreur lors de l'affichage du profil" });
    }
};

// Pour authentifier et vérifier si le MDP est correct
exports.loginUser = async (req, res) => {
    try {
      const { pseudonym, password } = req.body;
      if (!pseudonym || !password) {
        return res
          .status(400)
          .json({ message: "Pseudonyme et mot de passe sont requis." });
      }
  
      const user = await User.findOne({ pseudonym });
      if (!user) {
        return res.status(404).json({ message: "Utilisateur non trouvé." });
      }
  
      const isPasswordValid = await bcrypt.compare(password, user.password);
      if (!isPasswordValid) {
        return res.status(401).json({ message: "Mot de passe incorrect." });
      }
  
      const token = jwt.sign({ _id: user._id }, "secret");
  
      res.cookie("jwt", token, {
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000,
        sameSite: "Lax", 
        secure: false, 
      });
  
      const { password: _, ...userData } = user.toObject();
      res.status(200).json({
        message: "Connexion réussie",
        user: userData,
      });
    } catch (error) {
      res.status(500).json({
        message: "Erreur lors de la tentative de connexion",
        error: error.message,
      });
    }
  };

// Pour récupérer les données de l'utilisateur et les afficher sur le front
exports.getUser = async(req, res) => {
    try {
        const cookie = req.cookies['jwt'];
        const claims = jwt.verify(cookie, 'adams');
        console.log(claims._id)

        if (!claims) {
            res.status(401).send({ 
                message: "Vous n'êtes pas identifié"
            });
        }

        const user = await User.findOne({_id: claims._id});
        const { password, ...data } = await user.toJSON();

        res.send(data)
    } catch (error) {
        return res.status(401).send({
            message : " Erreur"
        })
    };
}; 