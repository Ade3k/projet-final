

const createUser = (userData) => {
    const newUser = { id: users.length + 1, ...userData };
    users.push(newUser);
    return newUser;
};

const getAllUsers = () => {
    return users;
};

const getUserById = (id) => {
    const user = users.find((u) => u.id === parseInt(id));
    if (!user) {
        throw new Error("Utilisateur introuvable");
    }
    return user;
};

const updateUser = (id, userData) => {
    const userIndex = users.findIndex((u) => u.id === parseInt(id));
    if (userIndex === -1) {
        throw new Error("Utilisateur introuvable");
    }
    users[userIndex] = { ...users[userIndex], ...userData };
    return users[userIndex];
};

const deleteUser = (id) => {
    const userIndex = users.findIndex((u) => u.id === parseInt(id));
    if (userIndex === -1) {
        throw new Error("Utilisateur introuvable");
    }
    const deletedUser = users.splice(userIndex, 1);
    return deletedUser;
};

module.exports = {
    createUser,
    getAllUsers,
    getUserById,
    updateUser,
    deleteUser,
};