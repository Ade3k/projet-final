// Composant pour gérer l'inscription des utilisateurs en collectant leurs informations via un formulaire
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms'; // Module Angular qui fournit des directives pour créer des formulaires et gérer leurs entrées.
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-signup',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './signup.component.html',
  styleUrl: './signup.component.css',
})
export class SignupComponent {
  constructor(
    private router: Router,
    private voiture1: AuthService) {
    this.titre = 'Salut Adams'
    console.log(this.titre)

  }

  titre: string; 

  pseudonym = '';
  email = '';
  password = '';
  firstName = '';
  lastName = '';
  age: number | null = null;
  genre = '';
  bio = '';

  navigateToLogin(): void {
    this.router.navigate(['login']);
  }
  onSubmit() {
    const userData = {
      pseudonym: this.pseudonym,
      email: this.email,
      password: this.password,
      firstName: this.firstName,
      lastName: this.lastName,
      age: this.age,
      genre: this.genre,
      bio: this.bio,
    };
    console.log(userData)
    this.voiture1.createUser(userData).subscribe({
      next: (response) => console.log('Utilisateur crée avec succès', response), 
      error: (error) => console.log('Erreur lors de la création', error),
      complete: () => console.log('Requête terminée')
    })
  }
}
