import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent { 
  pseudonym = ''
  password = ''

  constructor(private router: Router, private voiture2: AuthService) {}

  onSubmit() {
    const userData = {
      pseudonym: this.pseudonym,
      password: this.password,
    };
    console.log(userData)
    this.voiture2.login(userData).subscribe({
      next: (response) => {console.log('Connexion établie avec succès', response); 
      this.router.navigate(["dashboard"])}, 
      error: (error) => console.log('Erreur lors de la coonexion', error),
      complete: () => console.log('Requête terminée')
    })
  }

  navigateToSignup(): void{
  this.router.navigate(["signup"])
  }
}
