import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
private apiUrl = "http://localhost:3000/api/users"
  constructor(private http: HttpClient) { }

  createUser(userData: any) : Observable<any> {
    return this.http.post(`${this.apiUrl}/create`, userData)
  }

  login(donees: {pseudonym: string; password: string}) : Observable<any> {
    return this.http.post(`${this.apiUrl}/login`, donees)
  }

  getUser() : Observable<any> {
    return this.http.get(`${this.apiUrl}`)
  }
}
