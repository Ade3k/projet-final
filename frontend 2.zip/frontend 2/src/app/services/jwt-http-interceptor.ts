// Un intercepteur Angular pour modifier les requêtes HTTP.
// 'withCredentials' permet d'envoyer automatiquement cookies et en-têtes sensibles.

import { HttpInterceptorFn } from '@angular/common/http';

export const JwtHttpInterceptor: HttpInterceptorFn = (req, next) => {
  // Cloner la requête pour ajouter 'withCredentials'
  const clonedRequest = req.clone({
    withCredentials: true, // Inclut les informations sensibles comme les cookies.
  });

  // Passer la requête modifiée à la suite.
  return next(clonedRequest);
};
